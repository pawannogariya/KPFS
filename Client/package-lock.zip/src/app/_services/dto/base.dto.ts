export interface IDto {
}

export interface IIdDto<TId> extends IDto {
  id: TId;
}
