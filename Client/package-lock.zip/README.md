# angular-kpfs-bank-account-tool

Documentation at https://jasonwatmore.com/post/2022/12/22/angular-14-role-based-authorization-tutorial-with-example

JasonWatmore: https://jasonwatmore.com